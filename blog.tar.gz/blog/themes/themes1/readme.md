## Sam Hellawell's simple blog

Simplistic, responsive, metro blog theme used for my blog (www.samhellawell.info). Uses Disqus for comments so you'll have to edit article.php with your own Disqus code. This theme takes advantage of two extended fields (one of Anchor's amazing features).

Header text
-----------

	* Extend: Page
	* Type: HTML
	* Unique key: header-text
	* Label: Header text

Associated image
================

	* Extend: post
	* Type: image
	* Unique key: post-associate
	* Label: Associated image
	* File types, image width, image height: Leave blank