
			<div class="content-box" id="footer">

				<div class="left">

					<div class="footer-section">
						<h4><?php echo site_name(); ?></h4>
						<p><?php echo site_description(); ?></p>
					</div>

					<div class="footer-section">
						<h4>统计</h4>
						<p>
                            我至今已经发布了<?php echo total_posts(); ?>篇文章!
						</p>
					</div>

				</div>
				<div class="right">

					<div class="footer-section">
						<h4>分类</h4>
						<p>
							<ul>
							<?php while(categories()): ?>
								<li>
									<a href="<?php echo category_url(); ?>" title="<?php echo category_description(); ?>">
										<?php echo category_title(); ?>
									</a>
								</li>
							<?php endwhile; ?>
							</ul>
						</p>
					</div>

					<div class="footer-section">
						<h4>文章</h4>
						<p>
							<ul>
							<?php while(menu_items()): ?>
								<li>
									<a href="<?php echo menu_url(); ?>" title="<?php echo menu_title(); ?>">
										<?php echo menu_name(); ?>
									</a>
								</li>
							<?php endwhile; ?>
							</ul>
						</p>
					</div>

				</div>

				<div style="clear:both"></div>

			</div>

		</div>

        <script type="text/javascript">
        /* * * CONFIGURATION VARIABLES: EDIT BEFORE PASTING INTO YOUR WEBPAGE * * */
        var disqus_shortname = 'dantn'; // required: replace example with your forum shortname

        /* * * DON'T EDIT BELOW THIS LINE * * */
        (function () {
            var s = document.createElement('script'); s.async = true;
            s.type = 'text/javascript';
            s.src = '//' + disqus_shortname + '.disqus.com/count.js';
            (document.getElementsByTagName('HEAD')[0] || document.getElementsByTagName('BODY')[0]).appendChild(s);
                            
        }());
        </script>

    </body>
</html>
