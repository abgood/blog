<nav>
	<a class="icon bold" href="#bold">Bold</a>
	<a class="icon italic" href="#italic">Italic</a>
	<a class="icon list" href="#list">List</a>
	<a class="icon quote" href="#quote">Quote</a>
	<a class="icon code" href="#code">Code</a>
	<a class="icon link" href="#link">Link</a>
</nav>