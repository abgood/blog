<?php echo $header; ?>

<hgroup class="wrap">
	<h1>插件</h1>
</hgroup>

<section class="wrap">
	<?php echo $messages; ?>

	<p class="empty">
		<span class="icon"></span> 还没有推出.
	</p>
</section>

<?php echo $footer; ?>
