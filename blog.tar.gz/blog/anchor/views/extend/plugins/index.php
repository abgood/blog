<?php echo $header; ?>

<hgroup class="wrap">
	<h1>Plugins</h1>
</hgroup>

<section class="wrap">
	<?php echo $messages; ?>

	<p class="empty">
		<span class="icon"></span> Soon.
	</p>
</section>

<?php echo $footer; ?>