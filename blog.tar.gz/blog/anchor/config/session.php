<?php

return array(
	'driver' => 'database',
	'cookie' => 'anchorcms',
	'table' => 'blog_sessions',
	'lifetime' => 86400,
	'expire_on_close' => false,
	'path' => '/',
	'domain' => '',
	'secure' => false
);