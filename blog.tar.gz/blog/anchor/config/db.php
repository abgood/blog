<?php

return array(
	'default' => 'mysql',
	'prefix' => 'blog_',
	'connections' => array(
		'mysql' => array(
			'driver' => 'mysql',
			'hostname' => '127.0.0.1',
			'port' => 2433,
			'username' => 'root',
			'password' => '123456',
			'database' => 'blog',
			'charset' => 'utf8'
		)
	)
);