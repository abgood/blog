<?php

return array(
	'url' => '/',
	'index' => 'index.php',
	'timezone' => 'Asia/Shanghai',
	'key' => 'UCKRBQPbs2Z6RLmAN8aKYEGvc9MMU5RJ',
	'language' => 'en_GB',
	'encoding' => 'UTF-8'
);