<?php

return array(

	'menu' => '导航',

);