<?php

/*
 * Global is to replace common.php
 *
 * This global file will provide the majority of the translations in anchor
 * to remove duplicate translations in section specific language files.
 */
return array(

	// words
	'save' => '保存',
	'delete' => '删除',
	'update' => '更新',
	'edit' => '编辑',
	'editing' => '编辑中',
	'create' => '创建',
	'created' => '已创建',
	'submit' => '提交',
	'close' => '关闭',
	'status' => '统计',
	'manage' => '管理',
	'reset' => '重置',
	'all' => '所有',

	// pagination
	'next' => '下一个',
	'previous' => '上一个',
	'first' => '第一个',
	'last' => '最后一个',

	// statuses
	'draft' => '草稿',
	'archived' => '存档',
	'published' => '发布',
	'pending' => '待定',
	'approved' => '批准',
	'spam' => 'Spam',

	'inactive' => '待启用',
	'active' => '启用',

	// roles
	'administrator' => '管理员',
	'editor' => '编辑',
	'user' => '用户',

	'log_in' => '登录',
	'login' => '登录',
	'log_out' => '登出',
	'logout' => '登出',

	// pharses
	'visit_your_site' => '访问首页',
	'powered_by_anchor' => 'Powered by Anchor, version %s',
	'make_blogging_beautiful' => 'Make blogging beautiful.',

	// intro
	'welcome_to_anchor' => 'Welcome to Anchor',
	'welcome_to_anchor_lets_go' => 'Welcome to Anchor. Let’s go.',
	'run_the_installer' => 'Run the installer',

	// upgrade
	'upgrade' => '更新',
	'good_news' => '好消息!',
	'new_version_available' => '博客有新版本发布',
	'download_now' => '立刻下载',
	'upgrade_later' => '更新完成',

	// debug profiler
	'profile' => 'Profile',
	'profile_memory_usage' => 'Total memory usage',

	// messages
	'confirm_delete' => '你确定要删除么?不能反悔哦!'

);
